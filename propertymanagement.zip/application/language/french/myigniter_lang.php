<?php 

defined('BASEPATH') or exit('No direct script access allowed');

$lang['Create Amazing CRUD'] = 'Créez une application Web CRUD étonnante, CMS ou E-Commerce en Sec.';
